#
# This is the user-interface definition of a Shiny web application. You can
# run the application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)

# Define UI for application that draws a histogram
shinyUI(pageWithSidebar(
    # Application title
    titlePanel('Plotting the Soccer Match Prediction using shiny'),
    
    # Sidebar with 2 select inputs and a numeric input
    sidebarPanel(
        selectInput('xCol', 'X', names(Combined)),
        selectInput('yCol', 'Y', names(Combined))),
    
    # Shows the plot
    mainPanel(plotOutput('plot'))
))
