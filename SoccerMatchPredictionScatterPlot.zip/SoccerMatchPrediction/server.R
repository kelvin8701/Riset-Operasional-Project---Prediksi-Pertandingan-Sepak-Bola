#
# This is the server logic of a Shiny web application. You can run the
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)

# Define server logic required to draw a histogram
shinyServer(function(input, output, session) {
    # Get the data from the variables declared on the ui.R file
    df <- reactive({Combined[, c(input$xCol, input$yCol)]})
    
    # Create the plot
    output$plot <- renderPlot({plot(df(), pch = 20, cex = 3, col = "blue",
                                    main = "Away Model vs Home Model")})
})
